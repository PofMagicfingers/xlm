## Build Info - aarch64-linux-musl

aria2 1.37.0, static build from https://github.com/abcfy2/aria2-static-build/releases/tag/1.37.0
(`aria2-aarch64-linux-musl_static.zip`).
